const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const port = 3019;

const app = express();

// Middleware
app.use(express.static(__dirname));
app.use(express.urlencoded({ extended: true }));

// MongoDB connection
mongoose.connect('mongodb+srv://shanjeevkantharajah:S7pWSScZUs3OnND8@cluster-anubis.hhsnhks.mongodb.net/abcresturant', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const db = mongoose.connection;
db.once('open', () => {
    console.log('MongoDB connection successful');
});

// Define schema and model
const userSchema = new mongoose.Schema({
    name: String,
    email: String,
});

const Users = mongoose.model('data', userSchema);

// Serve HTML files
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'ABC Resturant.html')); // Serve the correct HTML file
});

// Handle POST requests to /post
app.post('/post', async (req, res) => {
    try {
        const { name, email } = req.body;
        const user = new Users({
            name,
            email
        });
        await user.save();
        console.log(user);
        res.send('User Submission Successful');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

// Start the server
app.listen(port, () => {
    console.log(`Server started on port ${port}`);
});
